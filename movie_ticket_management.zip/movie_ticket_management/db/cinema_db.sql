-- Create and use the database
CREATE DATABASE cinemaaa_db;
USE cinemaaa_db;

-- Drop existing tables to avoid conflicts
DROP TABLE IF EXISTS split_payment_users, split_payments, payments, tickets, seats, show_times, movies, theaters;

-- Movies Table
CREATE TABLE movies (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    duration INT NOT NULL,  -- Duration in minutes
    genre VARCHAR(100) NOT NULL,
    release_date DATE NOT NULL
);

-- Theaters Table (Fixed duplicate issue)
CREATE TABLE theaters (
    theater_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL
);

-- Show Times Table (✅ Added price column)
CREATE TABLE show_times (
    showtime_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_id INT NOT NULL,
    theater_id INT NOT NULL,
    showtime DATETIME NOT NULL,
    price DECIMAL(10,2) NOT NULL,  -- Price per ticket for this showtime
    FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
    FOREIGN KEY (theater_id) REFERENCES theaters(theater_id) ON DELETE CASCADE
);

-- Seats Table
CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    theater_id INT NOT NULL,
    seat_number VARCHAR(10) NOT NULL,
    is_booked BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (theater_id) REFERENCES theaters(theater_id) ON DELETE CASCADE
);

-- Tickets Table
CREATE TABLE tickets (
    ticket_id INT AUTO_INCREMENT PRIMARY KEY,
    showtime_id INT NOT NULL,
    seat_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,  -- ✅ Now ticket price will be stored here
    FOREIGN KEY (showtime_id) REFERENCES show_times(showtime_id) ON DELETE CASCADE,
    FOREIGN KEY (seat_id) REFERENCES seats(seat_id) ON DELETE CASCADE
);

-- Payments Table
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    transaction_id VARCHAR(255) NOT NULL UNIQUE,
    payment_status ENUM('pending', 'success', 'failed') NOT NULL DEFAULT 'pending',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);

-- Split Payments Table
CREATE TABLE split_payments (
    split_payment_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(10) NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed') NOT NULL DEFAULT 'pending',
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);

-- Split Payment Users Table
CREATE TABLE split_payment_users (
    split_payment_user_id INT AUTO_INCREMENT PRIMARY KEY,
    split_payment_id INT NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    share DECIMAL(5,2) NOT NULL,  -- Percentage of the total amount
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    payment_status ENUM('pending', 'completed', 'failed') NOT NULL DEFAULT 'pending',
    FOREIGN KEY (split_payment_id) REFERENCES split_payments(split_payment_id) ON DELETE CASCADE
);
