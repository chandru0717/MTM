from flask import Flask, render_template, request,flash,session, jsonify, redirect, url_for, json
import mysql.connector
from mysql.connector import Error
import requests
import hashlib
import base64
import json, uuid
from datetime import datetime
app = Flask(__name__)
app.secret_key = '....'  # Use a strong, random key

user_payment_links = {}

# PhonePe API credentials
PHONE_PE_MERCHANT_ID = 'your_merchant_id'
PHONE_PE_SALT_KEY = 'your_salt_key'
PHONE_PE_SALT_INDEX = 1  # Replace with your salt index
PHONE_PE_BASE_URL = 'https://api.phonepe.com/apis/hermes'  # Sandbox URL

# Database connection
def get_db_connection():
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='cinemaaa_db',
            user='root',  # Replace with your MySQL username
            password=''  # Replace with your MySQL password
        )

        if connection.is_connected():
            print("Successfully connected to the database")
            return connection
        else:
            print("Failed to connect to the database")
            return None
    except Error as err:
        print(f"Error: {err}")
        return None

# Home page
@app.route('/')
def index():
    return render_template('index.html')

# Movies
@app.route('/movies', methods=['GET', 'POST'])
def movies():
    connection = get_db_connection()
    if not connection:
        return "Database connection error", 500

    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        title = request.form['title']
        duration = request.form['duration']
        genre = request.form['genre']
        release_date = request.form['release_date']

        # Ensure the date is in the correct format
        try:
            formatted_date = datetime.strptime(release_date, "%Y-%m-%d").date()
        except ValueError:
            return "Invalid date format. Please use YYYY-MM-DD", 400  # Return an error if the date is invalid

        try:
            query = "INSERT INTO movies (title, duration, genre, release_date) VALUES (%s, %s, %s, %s)"
            cursor.execute(query, (title, duration, genre, formatted_date))
            connection.commit()
        except mysql.connector.Error as err:
            return f"Error executing query: {err}", 500

    cursor.execute("SELECT * FROM movies")
    movies = cursor.fetchall()
    cursor.close()
    connection.close()

    return render_template('movies.html', movies=movies)

@app.route('/theaters', methods=['GET', 'POST'])
def theaters():
    connection = get_db_connection()
    
    if connection is None:
        return "Database connection failed. Please check the logs.", 500  # Handle DB connection failure gracefully

    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        name = request.form.get('name')
        location = request.form.get('location')

        if name and location:  # Check if values are provided
            query = "INSERT INTO theaters (name, location) VALUES (%s, %s)"
            cursor.execute(query, (name, location))
            connection.commit()

    cursor.execute("SELECT * FROM theaters")
    theaters = cursor.fetchall()
    cursor.close()
    connection.close()
    
    return render_template('theaters.html', theaters=theaters)

# 🎬 Show_times Route 
@app.route('/show_times', methods=['GET', 'POST'])
def show_times_view():
    connection = get_db_connection()
    if connection is None:
        return "Database connection failed", 500  # Return HTTP 500 error

    cursor = connection.cursor(dictionary=True)

    if request.method == 'POST':
        movie_id = request.form['movie_id']
        theater_id = request.form['theater_id']
        showtime = request.form['showtime']

        query = "INSERT INTO show_times (movie_id, theater_id, showtime) VALUES (%s, %s, %s)"
        cursor.execute(query, (movie_id, theater_id, showtime))
        connection.commit()
        return redirect(url_for('show_times_view'))  # 🔄 Updated function reference

    # 🎥 Fetch movies and theaters
    cursor.execute("SELECT * FROM movies")
    movies = cursor.fetchall()

    cursor.execute("SELECT * FROM theaters")
    theaters = cursor.fetchall()

    # 🕒 Fetch showtimes with movie & theater names
    cursor.execute("""
    SELECT st.showtime_id, st.showtime, 
           m.movie_id, m.title AS movie_title, 
           t.theater_id, t.name AS theater_name
    FROM show_times AS st
    JOIN movies AS m ON st.movie_id = m.movie_id
    JOIN theaters AS t ON st.theater_id = t.theater_id  -- ✅ Fixed table name
    ORDER BY st.showtime ASC
""")

    show_times = cursor.fetchall()

    # 🔒 Close connection
    cursor.close()
    connection.close()
    return render_template('show_times.html', show_times=show_times, movies=movies, theaters=theaters)

# 🔄 SEATS ROUTE (fetch available 50 seats per showtime)
@app.route('/available_seats/<int:showtime_id>')
def available_seats(showtime_id):
    """Fetch available seats for a specific showtime"""
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)

    try:
        cursor.execute("""
            SELECT seats.seat_id, seats.seat_number 
            FROM seats
            JOIN show_times ON seats.theater_id = show_times.theater_id
            WHERE show_times.showtime_id = %s
              AND seats.is_booked = FALSE
            ORDER BY seats.seat_number
        """, (showtime_id,))
        seats = cursor.fetchall()

        return jsonify(seats)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

    finally:
        cursor.close()
        connection.close()

@app.route('/tickets', methods=['GET', 'POST'])
def tickets():
    connection = get_db_connection()
    cursor = connection.cursor(dictionary=True)
    try:
        # Fetch available showtimes
        cursor.execute("""
            SELECT st.showtime_id, st.showtime, 
                   m.title AS movie_title, 
                   t.name AS theater_name, st.price
            FROM show_times AS st
            JOIN movies AS m ON st.movie_id = m.movie_id
            JOIN theaters AS t ON st.theater_id = t.theater_id
            ORDER BY st.showtime ASC
        """)
        show_times = cursor.fetchall()

        booked_seats = session.get('booked_seats', [])  # Retrieve booked seats from session
        total_amount = session.get('total_amount', 0)  # Retrieve stored total amount

        if request.method == 'POST':
            showtime_id = request.form.get('showtime_id')
            seat_ids = request.form.getlist('seat_id')

            if not showtime_id or not seat_ids:
                flash("Missing showtime or seat selection!", "error")
                return redirect(url_for('tickets'))

            cursor.execute("SELECT price FROM show_times WHERE showtime_id = %s", (showtime_id,))
            price_data = cursor.fetchone()
            if not price_data:
                flash("Invalid showtime selected!", "error")
                return redirect(url_for('tickets'))

            price_per_seat = float(price_data['price'])
            total_price = len(seat_ids) * price_per_seat  # Calculate total price

            unavailable_seats = []
            for seat_id in seat_ids:
                cursor.execute("SELECT is_booked FROM seats WHERE seat_id = %s FOR UPDATE", (seat_id,))
                seat = cursor.fetchone()
                if not seat or seat['is_booked']:
                    unavailable_seats.append(seat_id)

            if unavailable_seats:
                flash(f"Seats {', '.join(map(str, unavailable_seats))} are already booked!", "error")
                return redirect(url_for('tickets'))

            # Book seats and insert into tickets
            for seat_id in seat_ids:
                cursor.execute(
                    "INSERT INTO tickets (showtime_id, seat_id, price) VALUES (%s, %s, %s)",
                    (showtime_id, seat_id, price_per_seat)
                )
                cursor.execute("UPDATE seats SET is_booked = TRUE WHERE seat_id = %s", (seat_id,))
            
            connection.commit()

            # Store payment details in session
            session['booked_seats'] = seat_ids
            session['total_amount'] = total_price
            session['payment_details'] = {
                'total_amount': total_price,
                'showtime_id': showtime_id,
                'seat_ids': seat_ids
            }

            flash(f"Tickets booked successfully! Total amount: ₹{total_price}. Proceed to payment.", "success")

            return redirect(url_for('tickets'))  # Stay on the same page

        return render_template('tickets.html', show_times=show_times, booked_seats=booked_seats, total_amount=total_amount)
    except Exception as e:
        connection.rollback()
        flash(f"Error: {str(e)}", "error")
        return redirect(url_for('tickets'))
    finally:
        cursor.close()
        connection.close()

@app.route('/payment', methods=['GET', 'POST'])
def payment():
    details = session.get('payment_details', {})
    total_amount = details.get('total_amount', 0)
    showtime_id = details.get('showtime_id')
    seat_ids = details.get('seat_ids', [])


    if request.method == 'POST':
        try:
            data = request.get_json()
            currency = data['currency']
            users = data['users']

            total_shares = sum(user['share'] for user in users)
            if total_shares != 100:
                return jsonify({'success': False, 'error': 'Total shares must be 100%'}), 400

            split_details = []
            for user in users:
                share = float(user['share'])
                amount = round((total_amount * share) / 100, 2)
                unique_id = str(uuid.uuid4())
                payment_link = url_for('user_payment_link', link_id=unique_id, _external=True)
                user_payment_links[unique_id] = {
                    'name': user['name'],
                    'amount': amount,
                    'currency': currency,
                    'payment_method': user['payment_method']
                }
                split_details.append({
                    'name': user['name'],
                    'share': share,
                    'amount': amount,
                    'payment_method': user['payment_method'],
                    'payment_link': payment_link
                })

            return jsonify({'success': True, 'split_details': split_details})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 400

    return render_template('payment.html', total_amount=total_amount, showtime_id=showtime_id, seat_ids=seat_ids)

@app.route('/payment/<link_id>', methods=['GET'])
def user_payment_link(link_id):
    user_data = user_payment_links.get(link_id)
    if user_data:
        return render_template('user_payment.html', user=user_data)
    return "Invalid or expired payment link.", 404

@app.route('/process-split-payment', methods=['POST'])
def process_split_payment():
    connection = None
    cursor = None
    try:
        data = request.get_json()
        split_details = data.get('split_details', [])
        showtime_id = data.get('showtime_id')
        seat_ids = data.get('seat_ids', [])

        if not split_details or not showtime_id or not seat_ids:
            return jsonify({'success': False, 'error': 'Missing required data'}), 400

        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # Process each user's payment (mocked success response)
        processed_payments = [{'name': user['name'], 'amount': user['amount'], 'status': 'success'} for user in split_details]

        # Generate a ticket ID
        ticket_id = str(uuid.uuid4())[:8]

        # Update ticket records for each seat
        for seat_id in seat_ids:
            cursor.execute(
                "UPDATE tickets SET ticket_id = %s WHERE showtime_id = %s AND seat_id = %s",
                (ticket_id, showtime_id, seat_id)
            )

        connection.commit()
        return jsonify({'success': True, 'processed_payments': processed_payments, 'ticket_id': ticket_id})

    except Exception as e:
        if connection:
            connection.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

if __name__ == '__main__':
    app.run(debug=True)


